"""
GCM Web UI Backend Application
Main application package initialization
"""

__version__ = "1.0.0"

# Made with Bob
